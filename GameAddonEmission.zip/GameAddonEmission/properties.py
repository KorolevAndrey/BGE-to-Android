import bpy
from bpy.props import BoolProperty, FloatVectorProperty, StringProperty, PointerProperty

class MaterialProperties1(bpy.types.PropertyGroup):
    emcolor = FloatVectorProperty(name="Emmission Color", 
                                        subtype='COLOR', 
                                        default=[1.0,1.0,1.0])


def register():
    bpy.utils.register_class(MaterialProperties1)
    bpy.types.Material.custom_prop1 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=MaterialProperties1,
            )


def unregister():
    del bpy.types.Material.custom_prop1
    bpy.utils.unregister_class(MaterialProperties1)

