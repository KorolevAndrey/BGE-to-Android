import bpy

class MaterialUtilityPanel1(bpy.types.Panel):
    bl_label = "Game panel"
    bl_idname = "MATREIAL_PT_materialutilitypanel1"

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"

    def draw(self, context):
        layout = self.layout
        if context.active_object.material_slots.data.active_material:
            am = context.active_object.material_slots.data.active_material
            box = layout.box()
            row = box.row()
            row.prop(am.custom_prop1, "emcolor")
        else:
            print('no active material')
