import bpy
from bpy.props import FloatVectorProperty, StringProperty, PointerProperty

class MaterialExportProperties1(bpy.types.PropertyGroup):
    #mesh_path = StringProperty(name="Mesh Path",
    #                                    default="/media/models")
    pass


def register():
    bpy.utils.register_class(MaterialExportProperties1)
    bpy.types.Scene.custom_prop4 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=MaterialExportProperties1,
            )

def unregister():
    del bpy.types.Scene.custom_prop4
    bpy.utils.unregister_class(MaterialExportProperties1)
