import bpy
import os
import math

def rem_sp_chr(z):
    removeSpecialChars = z.translate ({ord(c): "_" for c in " !@#$%^&*()[]{};:,./<>?\|`~-=+"})
    return removeSpecialChars

def sr(val):
    return str(round(val,4))

def sr1(val):
    pideg = math.pi / 180.0
    return str(round(val/pideg,4))

def sr2(val):
    return str(round(val*255.0,4))

def sr3(val):
    return str(val).upper()

def doSaveObjs():
    sc = bpy.data.scenes['Scene']
    camsc = sc.camera
    camera_name = "Camera"
    cam = bpy.data.cameras[camera_name]
    objects = sc.objects

    blend_file_path = bpy.data.filepath
    directory = os.path.dirname(blend_file_path)


    materials_path = '/media/materials'
    texturesfull_path = '/media/textures'
    textures_path = '/media/textures'
    #scene_file = 'simple.scene'
    mesh_path = '/media/models'

    waserr = False
    for o in objects:
        if o.type != 'CAMERA' and o.rotation_mode != 'ZYX':
            print('Error: ' + o.name + ' rotation_mode != ZYX')
            waserr = True
        if o.type == 'CAMERA' and o.rotation_mode != 'ZXY':
            print('Error: CAMERA ' + o.name + ' rotation_mode != ZXY')
            waserr = True
    if waserr == True:
        return

    obj_name = ''
    for o in objects:
        if o.type == 'MESH':    
            if o.parent != None and o.parent.type == 'ARMATURE':
                obj_name = rem_sp_chr(o.parent.name)
            else:
                obj_name = rem_sp_chr(o.name)

            with open(directory+materials_path+'/'+obj_name+".material", "w") as a_file:
                m = o.material_slots[0]
                if m != None:
                    ma = m.material
                    if ma != None:
                        a_file.write('material_name:'+ma.name+'\n')                
                        mt = ma.texture_slots[0]
                        if mt != None and mt.texture.type == 'IMAGE':
                            #if mt.texture.image.filepath != '':
                                #a_file.write('texture0:')
                                #base=os.path.basename('/root/dir/sub/file.ext')
                                #'file.ext'
                                #os.path.splitext(base)
                                #a_file.write(mt.texture.image.filepath.replace('\\','/').replace('//','/').replace('/media/', '')+'\n')
                            #else:
                            mt.texture.image.save_render(directory+texturesfull_path+"/" + os.path.splitext(mt.texture.image.name)[0] + ".png")
                            a_file.write('texture0:'+textures_path+"/" + os.path.splitext(mt.texture.image.name)[0] + ".png"+'\n')
                            a_file.write('texture1:\n')
                            a_file.write('texture2:\n')
                        else:
                            a_file.write('texture0:\n')
                            a_file.write('texture1:\n')
                            a_file.write('texture2:\n')
                        #--- shader
                        a_file.write('shaders:\n')
                        #--- flags
                        a_file.write('use_transparency:'+sr3(ma.use_transparency)+'\n')
                        # -- colors                                                
                        a_file.write('diffuse_color:'+sr2(ma.diffuse_color[0]) + ',')
                        a_file.write(sr2(ma.diffuse_color[1]) + ',')
                        a_file.write(sr2(ma.diffuse_color[2]) + ',')
                        a_file.write(sr2(ma.alpha) + '\n')
                        a_file.write('emmission_color:'+sr2(ma.custom_prop1.emcolor[0]) + ',')
                        a_file.write(sr2(ma.custom_prop1.emcolor[1]) + ',')
                        a_file.write(sr2(ma.custom_prop1.emcolor[2]) + ',')
                        a_file.write('255.0\n')
                    else:
                        a_file.write('material_name:\n')
                        a_file.write('texture0:\n')
                        a_file.write('shader:\n')
                        a_file.write('use_transparency:\n')
                        a_file.write('diffuse_color:\n')
                        a_file.write('emmission_color:\n')
