import bpy
from . import saveobjs

class MY_OT_MaterialExportButton1(bpy.types.Operator):
    """MeshExportButton"""
    bl_idname = "my.materialexportbutton1"
    bl_label = "Material Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        print('MaterialExport start')
        saveobjs.doSaveObjs()
        print('MaterialExport end')
        return {'FINISHED'}            # this lets blender know the operator finished successfully.


def register():
    bpy.utils.register_class(MY_OT_MaterialExportButton1)


def unregister():
    bpy.utils.unregister_class(MY_OT_MaterialExportButton1)
