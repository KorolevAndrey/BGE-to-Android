import bpy
from . import saveobjs

class MY_OT_LogicExportButton1(bpy.types.Operator):
    """MeshExportButton"""
    bl_idname = "my.logicexportbutton1"
    bl_label = "Logic Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        print('LogicExport start')
        saveobjs.doSaveObjs()
        print('LogicExport end')
        return {'FINISHED'}            # this lets blender know the operator finished successfully.


def register():
    bpy.utils.register_class(MY_OT_LogicExportButton1)


def unregister():
    bpy.utils.unregister_class(MY_OT_LogicExportButton1)
