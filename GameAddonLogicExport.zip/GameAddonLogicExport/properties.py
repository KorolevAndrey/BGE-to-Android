import bpy
from bpy.props import FloatVectorProperty, StringProperty, PointerProperty

class LogicExportProperties1(bpy.types.PropertyGroup):
    #mesh_path = StringProperty(name="Mesh Path",
    #                                    default="/media/models")
    pass


def register():
    bpy.utils.register_class(LogicExportProperties1)
    bpy.types.Scene.custom_prop5 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=LogicExportProperties1,
            )

def unregister():
    del bpy.types.Scene.custom_prop5
    bpy.utils.unregister_class(LogicExportProperties1)
