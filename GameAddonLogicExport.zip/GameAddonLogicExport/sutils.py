import bpy
import os
import math

def get_dir():
    filepath = bpy.data.filepath
    directory = os.path.dirname(filepath)
    return directory

def appF(destinationfn, sstr):
    with open(destinationfn, 'a') as outfile:
        outfile.write(sstr)

def writeF(destinationfn, sstr):
    with open(destinationfn, 'w') as outfile:
        outfile.write(sstr)

def rem_sp_chr(z):
    removeSpecialChars = z.translate ({ord(c): "_" for c in " !@#$%^&*()[]{};:,./<>?\|`~-=+"})
    return removeSpecialChars

def add_OBJECT(obj):
    sstr = ''
    #objid = add_OBJECT(name)
    #sstr += '       curObjId = add_OBJECT("' + obj.name + '") \n'
    sstr += '       curObjId = get_OBJECT_ID("' + obj.name + '") \n'
    return sstr

def add_has_logic(obj, oflag):
    sstr = ''
    sstr += '       OBJS[curObjId].base.has_logic = ' + oflag + ' \n'
    return sstr

def add_has_script(obj, oflag):
    sstr = ''
    sstr += '       OBJS[curObjId].base.has_script = ' + oflag + ' \n'
    return sstr

def add_KEYBOARD_sensor(sens):
    sstr = ''
    #add_KEYBOARD_sensor(name as string, evt_type as integer, key_code as integer, 
    #                    key_name as string, pulse_l as integer, tap_l as integer, skip_fr as integer)
    #add_KEYBOARD_sensor("k_w", 0, 87, "W", TRUE, FALSE, 0)
    #
    sstr += '       add_KEYBOARD_sensor("' + sens.name + '", 0, KEY_' + sens.key + ', "' + sens.key + '", ' + str(sens.use_pulse_true_level).upper() + ', ' + str(sens.use_tap).upper() + ', ' + str(sens.tick_skip)  + ') \n'
    return sstr

def add_MOUSE_sensor(sens):
    sstr = ''
    #add_MOUSE_sensor("m_0", 0, 0, TRUE, FALSE, 0)
    sstr += '       add_MOUSE_sensor("' + sens.name + '", 0, MSE_' + sens.mouse_event + ', ' + str(sens.use_pulse_true_level).upper() + ', ' + str(sens.use_tap).upper() + ', ' + str(sens.tick_skip)  + ') \n'
    return sstr

def add_ALWAYS_sensor(sens):
    sstr = ''
    #add_ALWAYS_sensor("always", TRUE, FALSE, 0)
    sstr += '       add_ALWAYS_sensor("' + sens.name + '", ' + str(sens.use_pulse_true_level).upper() + ', ' + str(sens.use_tap).upper() + ', ' + str(sens.tick_skip)  + ') \n'
    return sstr

def add_SIMPLE_MOTION_actuator(act):
    act_x = str(round(act.offset_location[0], 5))
    act_y = str(round(act.offset_location[1], 5))
    act_z = str(round(act.offset_location[2], 5))
    act_rx = str(round((180.0 * act.offset_rotation[0])/math.pi, 5))
    act_ry = str(round((180.0 * act.offset_rotation[1])/math.pi, 5))
    act_rz = str(round((180.0 * act.offset_rotation[2])/math.pi, 5))
    pos_local_flag = str(act.use_local_location).upper()
    rot_local_flag = str(act.use_local_rotation).upper()
    sstr = ''
    #add_SIMPLE_MOTION_actuator(name as string, x as float, y as float, z as float, rx as float, ry as float, rz as float, 
    #                           pos_local_flag as integer, rot_local_flag as integer )
    #add_SIMPLE_MOTION_actuator("m_w", 0.0, 0.2, 0.0, 0.0, 0.0, 0.0,  TRUE, NO_VALUE )
    if act.offset_rotation[0] + act.offset_rotation[1] + act.offset_rotation[2] == 0.0:
        rot_local_flag = 'NO_VALUE'
    if act.offset_location[0] + act.offset_location[1] + act.offset_location[2] == 0.0:
        pos_local_flag = 'NO_VALUE'
    sstr += '       add_SIMPLE_MOTION_actuator("' + act.name + '", ' + act_x + ', '+ act_y + ', ' + act_z + ', ' + act_rx + ', ' + act_ry + ', '+ act_rz + ', ' + pos_local_flag + ', ' + rot_local_flag + ') \n'
    return sstr


def add_ACTION_actuator(act):
    sstr = ''
    #add_ACTION_actuator("walk", 1, 40.0, 1,  50, 0.3, PLAY_LOOP)
    #
    sstr += '       add_ACTION_actuator("' + act.name + '", ' + str(act.priority) + ', 40.0, ' + str(act.frame_start) + ', ' + str(act.frame_end) + ', ' + str(round(act.frame_blend_in/30.0,5)) + ', PLAY_LOOP) \n'
    return sstr

def add_AND_controller(cont, senss, acts):
    sstr = ''
    #add_AND_controller("and_always_idle", s1("always"), s1("idle"))
    #
    ssv = ''
    for v in senss:
        if ssv != '':
            ssv += ',"' + v + '"'
        else:
            ssv += '"' + v + '"'
    aav = ''
    for v in acts:
        if aav != '':
            aav += ',"' + v + '"'
        else:
            aav += '"' + v + '"'

    ss = 's' + str(len(senss)) + '(' + ssv + ')'
    aa = 's' + str(len(acts)) + '(' + aav + ')'
    sstr += '       add_AND_controller("' + cont.name + '", ' + ss + ', ' + aa + ') \n'
    return sstr

def add_OR_controller(cont, senss, acts):
    sstr = ''
    #add_OR_controller("or_always_idle", s1("always"), s1("idle"))
    #
    ssv = ''
    for v in senss:
        if ssv != '':
            ssv += ',"' + v + '"'
        else:
            ssv += '"' + v + '"'
    aav = ''
    for v in acts:
        if aav != '':
            aav += ',"' + v + '"'
        else:
            aav += '"' + v + '"'

    ss = 's' + str(len(senss)) + '(' + ssv + ')'
    aa = 's' + str(len(acts)) + '(' + aav + ')'
    sstr += '       add_OR_controller("' + cont.name + '", ' + ss + ', ' + aa + ') \n'
    return sstr

def add_SCRIPT_controller(cont, obj, senss, acts):
    sstr = ''
    #
    #
    ssv = ''
    for v in senss:
        if ssv != '':
            ssv += ',"' + v + '"'
        else:
            ssv += '"' + v + '"'
    aav = ''
    for v in acts:
        if aav != '':
            aav += ',"' + v + '"'
        else:
            aav += '"' + v + '"'
    
    sstr_a, sstr_f, sstr_c = getScriptAddText(cont)
    
    sstr += '      if OBJS[curObjId].name = "' + obj.name + '" \n'
    ss = 's' + str(len(senss)) + '(' + ssv + ')'
    aa = 's' + str(len(acts)) + '(' + aav + ')'
    sstr += '           contName = "'+cont.name+'" \n'
    sstr += '           contSensors = '+ss+' \n'
    sstr += '           contActuators = '+aa+' \n'
    sstr += '           //# script \n'
    sstr += sstr_c
    sstr += '      endif \n'
    return sstr_a, sstr_f, sstr

def getScriptAddText(cont):
    #print(type(controllers[0]) == bpy.types.PythonController)
    sstr_a = ''
    sstr_f = ''
    sstr_c = ''
    writeOn = False
    writeOn1 = False            
    writeOn2 = False            
    for line in cont.text.lines:
        if line.body.find('#vars') >= 0:
            writeOn = True
        if line.body.find('#/vars') >= 0:
            writeOn = False
        if line.body.find('#funcs') >= 0:
            writeOn1 = True
        if line.body.find('#/funcs') >= 0:
            writeOn1 = False
        if line.body.find('#code') >= 0:
            writeOn2 = True
        if line.body.find('#/code') >= 0:
            writeOn2 = False
        if writeOn:
            sstr_a += '       ' + line.body + ' \n'
        if writeOn1:
            sstr_f += '       ' + line.body + ' \n'
        if writeOn2:
            sstr_c += '           ' + line.body + ' \n'
    return sstr_a, sstr_f, sstr_c

