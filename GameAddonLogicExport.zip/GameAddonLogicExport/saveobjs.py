import bpy
import os
import math
from . import sutils


def doSaveObjs():

    sc = bpy.data.scenes['Scene']

    localdir = sutils.get_dir()

    logic_path = localdir + '/media/logic/include'
    logic_path_a = localdir + '/media/logic/include/all'

    alogic_path = '/media/logic/include'
    alogic_path_a = '/media/logic/include/all'

    all_a_fn = logic_path + '/' + 'script_a.agc'
    all_f_fn = logic_path + '/' + 'script_f.agc'
    all_s_fn = logic_path + '/' + 'script_s.agc'
    all_a = ''
    all_a1 = ''
    all_f = ''
    all_s = ''
    all_s1 = ''

    sutils.writeF(all_a_fn, '      //#start\n')
    sutils.writeF(all_f_fn, '      //#start\n')
    sutils.writeF(all_s_fn, '      //#start\n')


    objs = bpy.data.objects
    for obj in objs:
        has_script = False
        obj_name = sutils.rem_sp_chr(obj.name)
        

    # ActuatorSensor, AlwaysSensor, ArmatureSensor, 
    # CollisionSensor, DelaySensor, JoystickSensor, 
    # KeyboardSensor, MessageSensor, MouseSensor, NearSensor, 
    # PropertySensor, RadarSensor, RandomSensor, RaySensor 

    # AndController, ExpressionController, NandController, 
    # NorController, OrController, PythonController, XnorController, 
    # XorController

    # ActionActuator, ArmatureActuator, CameraActuator, ConstraintActuator, 
    # EditObjectActuator, Filter2DActuator, GameActuator, MessageActuator, 
    # MouseActuator, ObjectActuator, ParentActuator, PropertyActuator, RandomActuator, 
    # SceneActuator, SoundActuator, StateActuator, SteeringActuator, VisibilityActuator

        sstr = ''
        sstr_s = ''
        sstr_c = ''
        sstr_sc = ''
        sstr_sca = ''
        sstr_scf = ''
        sstr_sa = ''
        sstr_sf = ''
        sstr_ss = ''
        sstr_a = ''
        uni_sens = {}
        uni_conts = {}
        uni_acts = {}
        uni_cont_senss_names = {}
        uni_cont_senss = {}
        uni_cont_acts_names = {}
        uni_cont_acts = {}
        sensors = obj.game.sensors
        for sens in sensors:
            if not sens.name in uni_sens:
                uni_sens[sens.name] = sens
            controllers = sens.controllers
            for cont in controllers:
                if not cont.name in uni_conts:
                    uni_conts[cont.name] = cont
                if not cont.name+'_'+sens.name in uni_cont_senss_names:
                    uni_cont_senss_names[cont.name+'_'+sens.name] = sens.name
                    if not cont.name in uni_cont_senss:
                        uni_cont_senss[cont.name] = []
                    uni_cont_senss[cont.name].append(sens.name)
                actuators = cont.actuators
                for act in actuators:
                    if not act.name in uni_acts:
                        uni_acts[act.name] = act
                    if not cont.name+'_'+act.name in uni_cont_acts_names:
                        uni_cont_acts_names[cont.name+'_'+act.name] = act.name
                        if not cont.name in uni_cont_acts:
                            uni_cont_acts[cont.name] = []
                        uni_cont_acts[cont.name].append(act.name)

        for sens_k in uni_sens:
            sens = uni_sens[sens_k]
            if type(sens) == bpy.types.AlwaysSensor:
                sstr_s += sutils.add_ALWAYS_sensor(sens)
            if type(sens) == bpy.types.KeyboardSensor:
                sstr_s += sutils.add_KEYBOARD_sensor(sens)
            if type(sens) == bpy.types.MouseSensor:
                sstr_s += sutils.add_MOUSE_sensor(sens)

        for act_k in uni_acts:
            act = uni_acts[act_k]
            if type(act) == bpy.types.ObjectActuator:
                sstr_a += sutils.add_SIMPLE_MOTION_actuator(act)
            if type(act) == bpy.types.ActionActuator:
                sstr_a += sutils.add_ACTION_actuator(act)

        for cont_k in uni_conts:
            cont = uni_conts[cont_k]
            if type(cont) == bpy.types.AndController:
                sstr_c += sutils.add_AND_controller(cont, uni_cont_senss[cont.name], uni_cont_acts[cont.name])
            if type(cont) == bpy.types.OrController:
                sstr_c += sutils.add_OR_controller(cont, uni_cont_senss[cont.name], uni_cont_acts[cont.name])
            if type(cont) == bpy.types.PythonController:
                sstr_sa, sstr_sf, sstr_ss = sutils.add_SCRIPT_controller(cont, obj, uni_cont_senss[cont.name], uni_cont_acts[cont.name])
                sstr_sca += sstr_sa
                sstr_sca += '\n'
                sstr_scf += sstr_sf
                sstr_scf += '\n'
                sstr_sc += sstr_ss
                sstr_sc += '\n'
                has_script = True
              
        sutils.appF(all_a_fn, '      //#' + obj.name + '\n')
        sutils.appF(all_a_fn, '      //#' + obj.name + '\n')
        sutils.appF(all_f_fn, '      //#' + obj.name + '\n')

        sstr += sutils.add_OBJECT(obj)
        if len(sensors) > 0:
            sstr += sutils.add_has_logic(obj, 'TRUE')
        if has_script == True:
            sstr += sutils.add_has_script(obj, 'TRUE')
        
        sutils.appF(all_a_fn, sstr)
        sutils.appF(all_a_fn, '       //# sensors \n')
        sutils.appF(all_a_fn, sstr_s)
        sutils.appF(all_a_fn, '       //# actuators \n')
        sutils.appF(all_a_fn, sstr_a)
        sutils.appF(all_a_fn, '       //# controllers \n')
        sutils.appF(all_a_fn, sstr_c)
        
        sutils.appF(all_a_fn, '      //# add script \n')
        sutils.appF(all_a_fn, sstr_sca)

        sutils.appF(all_f_fn, '      //# functions \n')
        sutils.appF(all_f_fn, sstr_scf)

        all_s += '      //#' + obj.name + '\n'
        all_s += sstr_sc


    all_s1 += 'function all_SCRIPT_controllers() \n'
    all_s1 += '     local contName as string \n'
    all_s1 += '     local contSensors as string[] \n'
    all_s1 += '     local contActuators as string[] \n'
    all_s1 += ' \n'
    all_s1 += all_s
    all_s1 += ' \n'
    all_s1 += 'endfunction \n'

    sutils.appF(all_s_fn, all_s1)

    sutils.appF(all_a_fn, '      //#end\n')
    sutils.appF(all_f_fn, '      //#end\n')
    sutils.appF(all_s_fn, '      //#end\n')

