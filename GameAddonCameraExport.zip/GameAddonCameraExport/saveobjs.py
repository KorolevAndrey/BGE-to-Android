import bpy
import os
import math

def sr(val):
    return str(round(val,4))

def sr1(val):
    pideg = math.pi / 180.0
    return str(round(val/pideg,4))

def sr2(val):
    return str(round(val*255.0,4))

def sr3(val):
    return str(val).upper()

def doSaveObjs():
    sc = bpy.context.scene
    camera_name = "Camera"
    cam = bpy.data.cameras[camera_name]
    objects = sc.objects
    
    blend_file_path = bpy.data.filepath
    directory = os.path.dirname(blend_file_path)
    
    camera_path = '/media/camera'
    camera_file = 'simple.camera'

    waserr = False
    for o in objects:
        if o.type != 'CAMERA' and o.rotation_mode != 'ZYX':
            print('Error: ' + o.name + ' rotation_mode != ZYX')
            waserr = True
        if o.type == 'CAMERA' and o.rotation_mode != 'ZXY':
            print('Error: CAMERA ' + o.name + ' rotation_mode != ZXY')
            waserr = True
    if waserr == True:
        return


    with open(directory+camera_path+'/'+camera_file, "w") as a_file:
        for o in objects:
            if o.type == 'CAMERA' and o.name == camera_name:
                a_file.write('name:'+o.name+'\n')
                a_file.write('type:'+o.type+'\n')
                a_file.write('lens:'+sr(cam.lens)+'\n')
                a_file.write('clip_start:'+sr(cam.clip_start)+'\n')
                a_file.write('clip_end:'+sr(cam.clip_end)+'\n')            
                a_file.write('rotation_mode:'+sr3(o.rotation_mode)+'\n')
                a_file.write('location:'+sr(o.location.x)+',')
                a_file.write(sr(o.location.y)+',')
                a_file.write(sr(o.location.z)+'\n')
                a_file.write('rotation:'+sr1(o.rotation_euler.x)+',')
                a_file.write(sr1(o.rotation_euler.y)+',')
                a_file.write(sr1(o.rotation_euler.z)+'\n')  
                a_file.write('rotationq:'+sr(o.rotation_quaternion.x)+',')
                a_file.write(sr(o.rotation_quaternion.y)+',')
                a_file.write(sr(o.rotation_quaternion.z)+',')  
                a_file.write(sr(o.rotation_quaternion.w)+'\n')
