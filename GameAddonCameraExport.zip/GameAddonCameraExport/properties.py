import bpy
from bpy.props import FloatVectorProperty, StringProperty, PointerProperty

class CameraExportProperties1(bpy.types.PropertyGroup):
    #mesh_path = StringProperty(name="Mesh Path",
    #                                    default="/media/models")
    pass


def register():
    bpy.utils.register_class(CameraExportProperties1)
    bpy.types.Scene.custom_prop2 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=CameraExportProperties1,
            )

def unregister():
    del bpy.types.Scene.custom_prop2
    bpy.utils.unregister_class(CameraExportProperties1)
