import bpy
from . import saveobjs

class MY_OT_CameraExportButton1(bpy.types.Operator):
    """MeshExportButton"""
    bl_idname = "my.cameraexportbutton1"
    bl_label = "Camera Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        print('CameraExport start')
        saveobjs.doSaveObjs()
        print('CameraExport end')
        return {'FINISHED'}            # this lets blender know the operator finished successfully.


def register():
    bpy.utils.register_class(MY_OT_CameraExportButton1)


def unregister():
    bpy.utils.unregister_class(MY_OT_CameraExportButton1)
