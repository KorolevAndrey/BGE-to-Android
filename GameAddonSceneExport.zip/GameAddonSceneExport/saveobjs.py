import bpy
import os
import math

def rem_sp_chr(z):
    removeSpecialChars = z.translate ({ord(c): "_" for c in " !@#$%^&*()[]{};:,./<>?\|`~-=+"})
    return removeSpecialChars

def sr(val):
    return str(round(val,4))

def sr1(val):
    pideg = math.pi / 180.0
    return str(round(val/pideg,4))

def sr2(val):
    return str(round(val*255.0,4))

def sr3(val):
    return str(val).upper()

def doSaveObjs():
    sc = bpy.data.scenes['Scene']
    camsc = sc.camera
    camera_name = "Camera"
    cam = bpy.data.cameras[camera_name]
    objects = sc.objects

    blend_file_path = bpy.data.filepath
    directory = os.path.dirname(blend_file_path)

    scene_path = '/media/scene'
    scene_file = rem_sp_chr(sc.name)+'.scene'
    mesh_path = '/media/models'
    mat_path = '/media/materials'

    waserr = False
    for o in objects:
        if o.type != 'CAMERA' and o.rotation_mode != 'ZYX':
            print('Error: ' + o.name + ' rotation_mode != ZYX')
            waserr = True
        if o.type == 'CAMERA' and o.rotation_mode != 'ZXY':
            print('Error: CAMERA ' + o.name + ' rotation_mode != ZXY')
            waserr = True
    if waserr == True:
        return

    obj_cnt = 0
    with open(directory+scene_path+'/'+scene_file, "w") as a_file:
        obj_cnt = len(objects)
        a_file.write('obj_cnt:'+str(obj_cnt)+'\n')
        for o in objects:
            if o.type == 'MESH':
                if o.parent == None or (o.parent != None and o.parent.type != 'ARMATURE'):
                    a_file.write('name:'+o.name+'\n')
                    a_file.write('type:'+o.type+'\n')
                    a_file.write('model:'+mesh_path +'/'+ o.name + '.fbx'+'\n') 
                    #--- general
                    a_file.write('location:'+sr(o.location.x)+',')
                    a_file.write(sr(o.location.y)+',')
                    a_file.write(sr(o.location.z)+'\n')
                    a_file.write('rotation:'+sr1(o.rotation_euler.x)+',')
                    a_file.write(sr1(o.rotation_euler.y)+',')
                    a_file.write(sr1(o.rotation_euler.z)+'\n')  
                    #--- mat
                    a_file.write('material:'+mat_path+'/'+rem_sp_chr(o.name)+'.material\n')        
                else:
                    a_file.write('name:'+o.parent.name+'\n')
                    a_file.write('type:ARMATURE\n')
                    a_file.write('model:'+mesh_path +'/'+ rem_sp_chr(o.parent.name) + '.fbx'+'\n')
                    #--- general
                    a_file.write('location:'+sr(o.parent.location.x)+',')
                    a_file.write(sr(o.parent.location.y)+',')
                    a_file.write(sr(o.parent.location.z)+'\n')
                    a_file.write('rotation:'+sr1(o.parent.rotation_euler.x)+',')
                    a_file.write(sr1(o.parent.rotation_euler.y)+',')
                    a_file.write(sr1(o.parent.rotation_euler.z)+'\n')  
                    #--- mat
                    a_file.write('material:'+mat_path+'/'+rem_sp_chr(o.parent.name)+'.material\n')
            elif o.type != 'ARMATURE':
                a_file.write('name:'+o.name+'\n')
                a_file.write('type:'+o.type+'\n')
                a_file.write('model:\n')
                #--- general
                a_file.write('location:'+sr(o.location.x)+',')
                a_file.write(sr(o.location.y)+',')
                a_file.write(sr(o.location.z)+'\n')
                a_file.write('rotation:'+sr1(o.rotation_euler.x)+',')
                a_file.write(sr1(o.rotation_euler.y)+',')
                a_file.write(sr1(o.rotation_euler.z)+'\n')  
                #--- mat
                a_file.write('material:\n')
