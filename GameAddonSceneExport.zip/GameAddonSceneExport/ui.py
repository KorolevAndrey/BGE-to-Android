import bpy
from . import buttons

class SceneExportPanel1(bpy.types.Panel):
    bl_label = "Game Panel"
    bl_idname = "SCENE_PT_sceneexportpanel1"

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout       
        cp = context.scene.custom_prop3
        if cp != None:
            box = layout.box()
            row = box.row()
            #row.prop(cp, "mesh_path")
            #row = box.row()
            row.label("Note: savepath", icon="INFO")
            row = box.row()
            row.label("media/scene/", icon="DOT")
            row = box.row()
            row.operator(buttons.MY_OT_SceneExportButton1.bl_idname, icon="SCENE_DATA")
