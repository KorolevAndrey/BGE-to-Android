import bpy
from . import saveobjs

class MY_OT_SceneExportButton1(bpy.types.Operator):
    """MeshExportButton"""
    bl_idname = "my.sceneexportbutton1"
    bl_label = "Scene Export"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        print('SceneExport start')
        saveobjs.doSaveObjs()
        print('SceneExport end')
        return {'FINISHED'}            # this lets blender know the operator finished successfully.


def register():
    bpy.utils.register_class(MY_OT_SceneExportButton1)


def unregister():
    bpy.utils.unregister_class(MY_OT_SceneExportButton1)
