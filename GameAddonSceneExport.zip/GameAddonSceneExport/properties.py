import bpy
from bpy.props import FloatVectorProperty, StringProperty, PointerProperty

class SceneExportProperties1(bpy.types.PropertyGroup):
    #mesh_path = StringProperty(name="Mesh Path",
    #                                    default="/media/models")
    pass


def register():
    bpy.utils.register_class(SceneExportProperties1)
    bpy.types.Scene.custom_prop3 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=SceneExportProperties1,
            )

def unregister():
    del bpy.types.Scene.custom_prop3
    bpy.utils.unregister_class(SceneExportProperties1)
