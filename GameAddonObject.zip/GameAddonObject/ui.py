import bpy

class ObjectUtilityPanel1(bpy.types.Panel):
    bl_label = "Game panel"
    bl_idname = "OBJECT_PT_objectutilitypanel1"

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "object"

    def draw(self, context):
        layout = self.layout       
        if context.active_object != None:
            box = layout.box()
            row = box.row()
            row.prop(context.active_object.custom_prop1, "dont_export")