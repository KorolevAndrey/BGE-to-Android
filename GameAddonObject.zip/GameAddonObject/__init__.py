#--- ### Header
bl_info = {
    "name": "Game Custom Properties Object",
    "category": "Game Engine",
}

import bpy
import bpy.props

from . import ui, properties

def register():
    properties.register()
    bpy.utils.register_module(__name__)


def unregister():
    properties.unregister()
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()