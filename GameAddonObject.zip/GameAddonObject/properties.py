import bpy
from bpy.props import BoolProperty, FloatVectorProperty, StringProperty, PointerProperty

class ObjectProperties1(bpy.types.PropertyGroup):
    
    dont_export = BoolProperty(name="Don't export this object",
                                        default=False)



def register():
    bpy.utils.register_class(ObjectProperties1)
    bpy.types.Object.custom_prop1 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=ObjectProperties1,
            )

def unregister():
    del bpy.types.Object.custom_prop1
    bpy.utils.unregister_class(ObjectProperties1)