import bpy
from bpy.props import FloatVectorProperty, StringProperty, PointerProperty

class MeshExportProperties1(bpy.types.PropertyGroup):
    #mesh_path = StringProperty(name="Mesh Path",
    #                                    default="/media/models")
    pass


def register():
    bpy.utils.register_class(MeshExportProperties1)
    bpy.types.Scene.custom_prop1 = PointerProperty(
            name="Game Custom Properties",
            description="Game Custom Properties",
            type=MeshExportProperties1,
            )

def unregister():
    del bpy.types.Scene.custom_prop1
    bpy.utils.unregister_class(MeshExportProperties1)
