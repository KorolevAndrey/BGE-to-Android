import bpy
import os

def doSaveObjs():
    sc = bpy.context.scene
    cam = sc.camera
    objects = sc.objects

    blend_file_path = bpy.data.filepath
    mesh_path = '/media/models'
    directory = os.path.dirname(blend_file_path) + mesh_path
    if not os.path.exists(directory):
       os.makedirs(directory)

    target_file = ''
    tmp_pos = [0,0,0]
    tmp_rot = [0,0,0]

    waserr = False
    for o in objects:
        if o.type != 'CAMERA' and o.rotation_mode != 'ZYX':
            print('Error: ' + o.name + ' rotation_mode != ZYX')
            waserr = True
        if o.type == 'CAMERA' and o.rotation_mode != 'ZXY':
            print('Error: CAMERA ' + o.name + ' rotation_mode != ZXY')
            waserr = True
    if waserr == True:
        return

    for o in objects:
        if o.type == 'MESH':
            if o.parent != None and o.parent.type == 'ARMATURE':
                bpy.ops.object.select_all(action='DESELECT')
                o.select = True
                o.parent.select = True
                bpy.context.scene.objects.active = o.parent
                #bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                tmp_pos = o.parent.location.copy()
                tmp_rot = o.parent.rotation_euler.copy()
                o.parent.location = [0,0,0]
                o.parent.rotation_euler = [0,0,0]
                target_file = os.path.join(directory, o.parent.name + '.fbx')

                bpy.ops.export_scene.fbx(filepath=target_file, check_existing=False, axis_forward='Y', axis_up='Z', filter_glob="*.fbx",  ui_tab='MAIN', use_selection=True, global_scale=0.01, apply_unit_scale=True, apply_scale_options='FBX_SCALE_NONE', bake_space_transform=False, object_types={'ARMATURE', 'CAMERA', 'EMPTY', 'LAMP', 'MESH', 'OTHER'}, use_mesh_modifiers=True, use_mesh_modifiers_render=True, mesh_smooth_type='OFF', use_mesh_edges=False, use_tspace=False, use_custom_props=False, add_leaf_bones=False, primary_bone_axis='Y', secondary_bone_axis='X', use_armature_deform_only=False, armature_nodetype='NULL', bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=True, bake_anim_use_all_actions=True, bake_anim_force_startend_keying=True, bake_anim_step=1.0, bake_anim_simplify_factor=1.0,     path_mode='AUTO', embed_textures=False, batch_mode='OFF', use_batch_own_dir=True, use_metadata=True)        
                
                o.parent.location = tmp_pos            
                o.parent.rotation_euler = tmp_rot
            else:
                bpy.ops.object.select_all(action='DESELECT')
                o.select = True
                bpy.context.scene.objects.active = o
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                tmp_pos = o.location.copy()
                tmp_rot = o.rotation_euler.copy()
                o.location = [0,0,0]
                o.rotation_euler = [0,0,0]
                target_file = os.path.join(directory, o.name + '.fbx')

                bpy.ops.export_scene.fbx(filepath=target_file, check_existing=False, axis_forward='Y', axis_up='Z', filter_glob="*.fbx",  ui_tab='MAIN', use_selection=True, global_scale=0.01, apply_unit_scale=True, apply_scale_options='FBX_SCALE_NONE', bake_space_transform=False, object_types={'ARMATURE', 'CAMERA', 'EMPTY', 'LAMP', 'MESH', 'OTHER'}, use_mesh_modifiers=True, use_mesh_modifiers_render=True, mesh_smooth_type='OFF', use_mesh_edges=False, use_tspace=False, use_custom_props=False, add_leaf_bones=False, primary_bone_axis='Y', secondary_bone_axis='X', use_armature_deform_only=False, armature_nodetype='NULL', bake_anim=True, bake_anim_use_all_bones=True, bake_anim_use_nla_strips=True, bake_anim_use_all_actions=True, bake_anim_force_startend_keying=True, bake_anim_step=1.0, bake_anim_simplify_factor=1.0,     path_mode='AUTO', embed_textures=False, batch_mode='OFF', use_batch_own_dir=True, use_metadata=True)        
                
                o.location = tmp_pos
                o.rotation_euler = tmp_rot
