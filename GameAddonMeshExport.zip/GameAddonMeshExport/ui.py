import bpy
from . import buttons

class MeshExportPanel1(bpy.types.Panel):
    bl_label = "Game Panel"
    bl_idname = "SCENE_PT_meshexportpanel1"

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout       
        cp = context.scene.custom_prop1
        if cp != None:
            box = layout.box()
            row = box.row()
            #row.prop(cp, "mesh_path")
            #row = box.row()
            row.label("Note: savepaths", icon="INFO")
            row = box.row()
            row.label("media/models/", icon="DOT")
            row = box.row()
            row.label("media/textures/", icon="DOT")
            row = box.row()
            row.operator(buttons.MY_OT_MeshExportButton1.bl_idname, icon="OBJECT_DATA")
